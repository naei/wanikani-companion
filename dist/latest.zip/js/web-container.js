window.onload = function() {
  // load the WaniKani page iframe
  document.getElementById('wanikaniFrame').src = localStorage.toLink;
}